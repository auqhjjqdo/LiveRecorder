import typing

StrOrBytes = typing.Union[str, bytes]
